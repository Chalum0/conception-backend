import prisma from "../config/prisma.js";

export const RefreshTokenModel = prisma.refreshToken;

export default RefreshTokenModel;
