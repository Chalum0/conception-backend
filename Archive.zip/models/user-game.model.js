import prisma from "../config/prisma.js";

export const UserGameModel = prisma.userGame;

export default UserGameModel;
