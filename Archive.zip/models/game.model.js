import prisma from "../config/prisma.js";

export const GameModel = prisma.game;

export default GameModel;
